import { useState, useEffect, useCallback, useRef } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { 
  Shield, Zap, ExternalLink, RefreshCw, LogIn, Key, 
  Server, CheckCircle, XCircle, Cpu, Globe, Settings,
  Wifi, WifiOff, LogOut, Square, Activity, ChevronDown
} from 'lucide-react';
import pkg from '../package.json';

async function rustFetch(url: string, options: any = {}): Promise<Response> {
  const method = options.method || 'GET';
  const headers = options.headers || {};
  const body = options.body || null;
  
  try {
    const responseText = await invoke<string>('request_server', {
      method,
      url,
      headers,
      body,
    });
    
    return {
      ok: true,
      status: 200,
      json: async () => JSON.parse(responseText),
      text: async () => responseText,
    } as Response;
  } catch (err: any) {
    console.error("rustFetch error", err);
    let status = 500;
    let text = typeof err === 'string' ? err : (err.message || err.toString());
    if (typeof text === 'string' && text.startsWith('HTTP ')) {
      const parts = text.split(' : ');
      status = parseInt(parts[0].replace('HTTP ', ''), 10) || 500;
      text = parts.slice(1).join(' : ');
    }
    
    return {
      ok: false,
      status,
      json: async () => {
        try {
          return JSON.parse(text);
        } catch {
          return { error: text };
        }
      },
      text: async () => text,
    } as Response;
  }
}


// ─── Types ────────────────────────────────────────────────────────

interface ModelInfo {
  id: string;
  object?: string;
  owned_by?: string;
}

interface ModelsResponse {
  data: ModelInfo[];
  object?: string;
}

// ─── Constants ────────────────────────────────────────────────────


const LS_LANG_KEY = 'ag_lang';

const dict = {
  en: {
    secureClient: "Secure Proxy Client",
    serverUrl: "Server URL",
    accessToken: "Access Token",
    connect: "Connect",
    connecting: "Connecting...",
    connected: "Connected",
    ping: "Ping",
    status: "Status",
    active: "Active",
    tokenAuth: "Token authenticated",
    models: "Models",
    availModels: "Available AI models",
    credits: "Credits",
    totalCredits: "Total combined credits",
    server: "Server",
    proxyPing: "Proxy endpoint ping",
    ready: "Ready to Code?",
    connectToIDE: "Connect to Antigravity IDE with your secure proxy token. A local proxy on port 8047 will route all IDE requests through the Manager.",
    localProxy: "Local Proxy Active on",
    stop: "Stop",
    ideLaunched: "IDE launched successfully! Proxy running.",
    reconnect: "Reconnect IDE",
    connectTo: "Connect to",
    logout: "Logout",
    settings: "Settings",
    ideSettings: "IDE Settings",
    customExe: "Custom Executable Path (Optional)",
    leaveBlank: "Leave blank to use default OS path.",
    customDb: "Custom DB / AppData Path (Optional)",
    pathToVscdb: "Path to state.vscdb for portable installations.",
    done: "Done",
    saveReconnect: "Save and Reconnect",
    proxyUrlForIde: "Proxy URL for IDE:",
    error: "Error",
    offline: "Offline",
    availableModelsTitle: "Available Models",
    modelsCount: "models",
    serverConfig: "Server Configuration",
    daysLeft: "days left",
    serverStatus: "Server Status",
    support: "Support",
    getToken: "Get Token",
    plan: "Plan",
    checkForUpdates: "Check for Updates",
    checkingUpdates: "Checking for updates...",
    updateAvailable: "New Version Available",
    updateBtn: "Update Now",
    upToDate: "You have the latest version",
    updateError: "Failed to check or install update",
    updating: "Updating..."
  },
  ru: {
    secureClient: "Безопасный прокси-клиент",
    serverUrl: "Адрес сервера",
    accessToken: "Токен доступа",
    connect: "Подключиться",
    connecting: "Подключение...",
    connected: "Подключено",
    ping: "Пинг",
    status: "Статус",
    active: "Активен",
    tokenAuth: "Токен подтвержден",
    models: "Модели",
    availModels: "Доступные ИИ-модели",
    credits: "Кредиты",
    totalCredits: "Общий баланс кредитов",
    server: "Сервер",
    proxyPing: "Пинг до прокси",
    ready: "Готовы программировать?",
    connectToIDE: "Подключите Antigravity IDE, используя ваш токен. Локальный прокси на порту 8047 перенаправит все запросы IDE через Менеджер.",
    localProxy: "Локальный прокси запущен на",
    stop: "Остановить",
    ideLaunched: "IDE успешно запущена! Прокси работает.",
    reconnect: "Переподключить IDE",
    connectTo: "Подключить к",
    logout: "Выйти",
    settings: "Настройки",
    ideSettings: "Настройки IDE",
    customExe: "Путь к исполняемому файлу (Опционально)",
    leaveBlank: "Оставьте пустым для стандартного пути ОС.",
    customDb: "Путь к БД / AppData (Опционально)",
    pathToVscdb: "Путь к state.vscdb для портативных версий.",
    done: "Готово",
    saveReconnect: "Сохранить и переподключиться",
    proxyUrlForIde: "URL прокси для IDE:",
    error: "Ошибка",
    offline: "Не в сети",
    availableModelsTitle: "Доступные модели",
    modelsCount: "моделей",
    serverConfig: "Настройки сервера",
    daysLeft: "дней осталось",
    serverStatus: "Статус сервера",
    support: "Поддержка",
    getToken: "Получить токен",
    plan: "Тариф",
    checkForUpdates: "Проверить обновления",
    checkingUpdates: "Проверка обновлений...",
    updateAvailable: "Доступна новая версия",
    updateBtn: "Обновить сейчас",
    upToDate: "Установлена последняя версия",
    updateError: "Не удалось проверить или установить обновление",
    updating: "Обновление..."
  }
};

const LS_TOKEN_KEY = 'ag_token';
const LS_SERVER_KEY = 'ag_server_url';
const LS_IDE_TYPE_KEY = 'ag_ide_type';
const LS_CUSTOM_EXE_KEY = 'ag_custom_exe';
const LS_CUSTOM_DB_KEY = 'ag_custom_db';

const DEFAULT_SERVER_URL = 'http://45.128.204.95';

// ─── Model Display Helpers ────────────────────────────────────────

const MODEL_CATEGORIES: Record<string, { label: string; color: string; icon: string }> = {
  'gemini':  { label: 'Gemini',  color: 'from-blue-500 to-cyan-400',    icon: '✦' },
  'claude':  { label: 'Claude',  color: 'from-orange-500 to-amber-400', icon: '◈' },
  'gpt':     { label: 'GPT',     color: 'from-emerald-500 to-green-400',icon: '◉' },
};

const IDE_ALLOWED_MODELS = [
  'gemini-3.5-flash-medium',
  'gemini-3.5-flash-high',
  'gemini-3.5-flash-low',
  'gemini-3.1-pro-high',
  'gemini-3.1-pro-low',
  'claude-sonnet-4-6-thinking',
  'claude-opus-4-6-thinking',
  'gpt-oss-120b-medium'
];

function getModelCategory(modelId: string) {
  for (const [key, val] of Object.entries(MODEL_CATEGORIES)) {
    if (modelId.toLowerCase().includes(key)) return val;
  }
  return { label: 'Other', color: 'from-purple-500 to-pink-400', icon: '◇' };
}

function formatModelName(id: string): string {
  return id
    .replace(/-/g, ' ')
    .replace(/\b\w/g, c => c.toUpperCase());
}

function CountdownTimer({ resetTime }: { resetTime: string }) {
  const [timeLeft, setTimeLeft] = useState<string>('');

  useEffect(() => {
    const calculateTime = () => {
      const target = new Date(resetTime).getTime();
      const now = Date.now();
      const diff = target - now;

      if (diff <= 0) {
        setTimeLeft('now');
        return;
      }

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      const parts = [];
      if (hours > 0) parts.push(`${hours}h`);
      if (minutes > 0 || hours > 0) parts.push(`${minutes}m`);
      parts.push(`${seconds}s`);

      setTimeLeft(parts.join(' '));
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [resetTime]);

  if (!timeLeft) return null;
  return <span className="text-[10px] text-amber-500 font-medium ml-1 flex items-center gap-0.5">⏳ {timeLeft}</span>;
}

// ─── App Component ────────────────────────────────────────────────

export default function App() {
    const [lang, setLang] = useState<'en'|'ru'>('en');
  const [showLangDropdown, setShowLangDropdown] = useState(false);
  const t = dict[lang];

  useEffect(() => {
    const savedLang = localStorage.getItem(LS_LANG_KEY) as 'en'|'ru';
    if (savedLang) setLang(savedLang);
  }, []);

  const changeLang = (newLang: 'en'|'ru') => {
    setLang(newLang);
    localStorage.setItem(LS_LANG_KEY, newLang);
    setShowLangDropdown(false);
  };

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (!(e.target as Element).closest('.lang-dropdown')) {
        setShowLangDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const [token, setToken] = useState('');
  const [serverUrl, setServerUrl] = useState(DEFAULT_SERVER_URL);
  
  // Settings State
  const [showSettings, setShowSettings] = useState(false);
  const [ideType, setIdeType] = useState('Antigravity IDE');
  const [customExePath, setCustomExePath] = useState('');
  const [customDbPath, setCustomDbPath] = useState('');

  // Main App State
  const [models, setModels] = useState<ModelInfo[]>([]);
  const [modelPercentages, setModelPercentages] = useState<Record<string, number>>({});
  const [modelResets, setModelResets] = useState<Record<string, string>>({});
  const [totalCredits, setTotalCredits] = useState<number | null>(null);
  const [creditOverages, setCreditOverages] = useState(false);
  const [connected, setConnected] = useState(false);
  const [expiresAt, setExpiresAt] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Client Update States
  const CURRENT_VERSION = pkg.version;
  const [updateInfo, setUpdateInfo] = useState<{
    version: string;
    name: string;
    body: string;
    asset_id: number;
    size: number;
  } | null>(null);
  const [checkingUpdates, setCheckingUpdates] = useState(false);
  const [updateError, setUpdateError] = useState('');
  const [updating, setUpdating] = useState(false);
  const [updateStatus, setUpdateStatus] = useState<'none' | 'up-to-date' | 'available' | 'error'>('none');

  const getOS = () => {
    const userAgent = window.navigator.userAgent.toLowerCase();
    if (userAgent.includes("win")) return "windows";
    if (userAgent.includes("mac")) return "macos";
    if (userAgent.includes("linux")) return "linux";
    return "windows";
  };

  const checkUpdates = async (silent = false) => {
    if (!silent) {
      setCheckingUpdates(true);
      setUpdateError('');
      setUpdateStatus('none');
    }
    try {
      const os = getOS();
      const res = await rustFetch(`${serverUrl}/v1/client-update?platform=${os}`);
      if (!res.ok) {
        throw new Error(`Failed to check updates: ${res.status}`);
      }
      const data = await res.json();
      if (data.version && data.version !== CURRENT_VERSION) {
        setUpdateInfo(data);
        setUpdateStatus('available');
      } else {
        setUpdateInfo(null);
        setUpdateStatus('up-to-date');
      }
    } catch (e: any) {
      console.error(e);
      if (!silent) {
        setUpdateError(e.message || 'Error checking for updates');
        setUpdateStatus('error');
      }
    } finally {
      if (!silent) setCheckingUpdates(false);
    }
  };

  const handleInstallUpdate = async () => {
    if (!updateInfo) return;
    setUpdating(true);
    setUpdateError('');
    try {
      const downloadUrl = `${serverUrl}/v1/client-update/download/${updateInfo.asset_id}`;
      await invoke('install_client_update', { downloadUrl });
    } catch (e: any) {
      setUpdateError(e.toString() || 'Failed to install update');
      setUpdating(false);
    }
  };
  const [ideConnecting, setIdeConnecting] = useState(false);
  const [ideSuccess, setIdeSuccess] = useState(false);
  const [serverOnline, setServerOnline] = useState<boolean | null>(null);
  const [ping, setPing] = useState<number | null>(null);
  const pingHistoryRef = useRef<number[]>([]);
  const [proxyRunning, setProxyRunning] = useState(false);
  const [tier, setTier] = useState<number | null>(null);

  // ─── Load saved state ────────────────────────────────────────────

  useEffect(() => {
    const savedToken = localStorage.getItem(LS_TOKEN_KEY);
    const savedServer = localStorage.getItem(LS_SERVER_KEY);
    const savedIdeType = localStorage.getItem(LS_IDE_TYPE_KEY);
    const savedExePath = localStorage.getItem(LS_CUSTOM_EXE_KEY);
    const savedDbPath = localStorage.getItem(LS_CUSTOM_DB_KEY);

    if (savedServer) setServerUrl(savedServer);
    if (savedIdeType) setIdeType(savedIdeType);
    if (savedExePath) setCustomExePath(savedExePath);
    if (savedDbPath) setCustomDbPath(savedDbPath);
    
    const url = savedServer || DEFAULT_SERVER_URL;
    
    if (savedToken) {
      setToken(savedToken);
      validateToken(savedToken, url);
    } else {
      checkServerHealth(url);
    }
  }, []);

  // ─── Server Health Check ─────────────────────────────────────────

  const checkServerHealth = useCallback(async (url: string) => {
    const startTime = performance.now();
    try {
      const res = await rustFetch(`${url}/health`, { 
        method: 'GET',
      });
      const endTime = performance.now();
      if (res.ok) {
        const rawPing = Math.round(endTime - startTime);
        pingHistoryRef.current.push(rawPing);
        if (pingHistoryRef.current.length > 5) {
            pingHistoryRef.current.shift();
        }
        setPing(Math.min(...pingHistoryRef.current));
        setServerOnline(true);
      } else {
        pingHistoryRef.current = [];
        setPing(null);
        setServerOnline(false);
      }
    } catch {
      pingHistoryRef.current = [];
      setPing(null);
      setServerOnline(false);
    }
  }, []);

  // ─── Token Validation via /v1/models ─────────────────────────────

  const validateToken = useCallback(async (tokenToUse: string, url?: string) => {
    const serverBase = url || serverUrl;
    if (!tokenToUse) return;
    
    setLoading(true);
    setError('');
    
    try {
      const res = await rustFetch(`${serverBase}/v1/models`, {
        headers: {
          'Authorization': `Bearer ${tokenToUse}`,
        },
      });

      if (res.ok) {
        const data: ModelsResponse = await res.json();
        const modelList = (data.data || []).filter(m => IDE_ALLOWED_MODELS.includes(m.id));
        setModels(modelList);
        
        try {
          const qRes = await rustFetch(`${serverBase}/v1/quota`, {
            headers: { 'Authorization': `Bearer ${tokenToUse}` },
          });
          if (qRes.ok) {
            const qData = await qRes.json();
            setTotalCredits(qData.total_credits);
            setExpiresAt(qData.expires_at || null);
            setCreditOverages(qData.enable_credit_overages);
            setModelPercentages(qData.models || {});
            setModelResets(qData.resets || {});
            setTier(qData.tier !== undefined ? qData.tier : null);
          }
        } catch (e) {
          console.error('Failed to fetch quota', e);
        }

        setConnected(true);
        setServerOnline(true);
        localStorage.setItem(LS_TOKEN_KEY, tokenToUse);
        localStorage.setItem(LS_SERVER_KEY, serverBase);
      } else if (res.status === 401) {
        throw new Error('Invalid token. Please check your API key.');
      } else if (res.status === 403) {
        // Manager returns detailed rejection reason in body
        try {
          const body = await res.json();
          const msg = body?.error?.message || 'Access denied';
          throw new Error(msg);
        } catch (e: any) {
          if (e.message && e.message !== 'Access denied') throw e;
          throw new Error('Token rejected (403). It may be expired or IP-limited.');
        }
      } else {
        throw new Error(`Server error (${res.status})`);
      }
    } catch (err: any) {
      if (err.name === 'TimeoutError' || err.name === 'AbortError') {
        setError('Connection timeout. Check server URL and make sure Manager is running.');
      } else {
        setError(err.message || 'Connection error');
      }
      setConnected(false);
      setModels([]);
      checkServerHealth(serverBase);
    } finally {
      setLoading(false);
    }
  }, [serverUrl, checkServerHealth]);

  useEffect(() => {
    if (serverOnline) {
      checkUpdates(true);
    }
  }, [serverOnline]);

  // ─── Handlers ────────────────────────────────────────────────────

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    validateToken(token, serverUrl);
  };

  const handleLogout = () => {
    localStorage.removeItem(LS_TOKEN_KEY);
    setToken('');
    setConnected(false);
    setModels([]);
    setModelResets({});
    setError('');
    setIdeSuccess(false);
    setTier(null);
  };

  const handleRefresh = () => {
    validateToken(token, serverUrl);
  };

  const handleConnect = async () => {
    setIdeConnecting(true);
    setIdeSuccess(false);
    try {
      await invoke('inject_token_and_start_ide', {
        token: token,
        proxyUrl: `${serverUrl}/v1`,
        ideType: ideType,
        customExePath: customExePath || null,
        customDbPath: customDbPath || null,
      });
      setIdeSuccess(true);
      setProxyRunning(true);
      setTimeout(() => setIdeSuccess(false), 5000);
    } catch (err: any) {
      setError(`IDE connection failed: ${err}`);
    } finally {
      setIdeConnecting(false);
    }
  };

  const handleStopProxy = async () => {
    try {
      await invoke('stop_proxy');
      setProxyRunning(false);
    } catch (err: any) {
      setError(`Failed to stop proxy: ${err}`);
    }
  };

  // Poll proxy status
  useEffect(() => {
    const checkProxy = async () => {
      try {
        const running = await invoke<boolean>('get_proxy_status');
        setProxyRunning(running);
      } catch { /* ignore */ }
    };
    checkProxy();
    const interval = setInterval(checkProxy, 3000);
    return () => clearInterval(interval);
  }, []);

  // Poll quota
  useEffect(() => {
    if (!connected || !token) return;
    const fetchQuota = async () => {
      try {
        const qRes = await rustFetch(`${serverUrl}/v1/quota`, {
          headers: { 'Authorization': `Bearer ${token}` },
        });
        if (qRes.ok) {
          const qData = await qRes.json();
          setTotalCredits(qData.total_credits);
            setExpiresAt(qData.expires_at || null);
          setCreditOverages(qData.enable_credit_overages);
          setModelPercentages(qData.models || {});
          setModelResets(qData.resets || {});
          setTier(qData.tier !== undefined ? qData.tier : null);
        }
      } catch (e) {
        // ignore periodic failures
      }
    };
    const interval = setInterval(fetchQuota, 10000);
    return () => clearInterval(interval);
  }, [connected, token, serverUrl]);

  // Poll server health / ping every 5 seconds
  useEffect(() => {
    checkServerHealth(serverUrl);
    const interval = setInterval(() => {
      checkServerHealth(serverUrl);
    }, 5000);
    return () => clearInterval(interval);
  }, [serverUrl, checkServerHealth]);

  const handleSaveServerUrl = () => {
    localStorage.setItem(LS_SERVER_KEY, serverUrl);
    localStorage.setItem(LS_IDE_TYPE_KEY, ideType);
    localStorage.setItem(LS_CUSTOM_EXE_KEY, customExePath);
    localStorage.setItem(LS_CUSTOM_DB_KEY, customDbPath);
    setShowSettings(false);
    checkServerHealth(serverUrl);
    if (token && connected) {
      validateToken(token, serverUrl);
    }
  };

  const toggleCreditOverages = async () => {
    try {
      const newState = !creditOverages;
      setCreditOverages(newState); // optimistic update
      await rustFetch(`${serverUrl}/v1/quota/config`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ enable_credit_overages: newState }),
      });
    } catch (e) {
      console.error('Failed to toggle config', e);
      setCreditOverages(!creditOverages); // revert on error
    }
  };

  // ─── Render: Login Screen ───────────────────────────────────────

  if (!connected) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center relative overflow-hidden text-white font-sans">
                {/* Language Dropdown */}
        <div className="absolute top-4 right-4 z-50 lang-dropdown">
          <button
            onClick={() => setShowLangDropdown(!showLangDropdown)}
            className="flex items-center space-x-1 px-3 h-10 bg-white/5 hover:bg-white/10 rounded-lg transition-colors border border-white/5 text-sm font-medium text-gray-300"
            title="Change Language"
          >
            <Globe className="w-4 h-4" />
            <span>{lang.toUpperCase()}</span>
            <ChevronDown className={`w-4 h-4 transition-transform ${showLangDropdown ? 'rotate-180' : ''}`} />
          </button>
          
          {showLangDropdown && (
            <div className="absolute right-0 mt-2 w-32 bg-[#1a1c23] border border-white/10 rounded-xl shadow-2xl py-1 z-50 overflow-hidden">
              <button
                onClick={() => changeLang('en')}
                className={`w-full text-left px-4 py-2 text-sm hover:bg-white/5 transition-colors ${lang === 'en' ? 'text-blue-400 font-medium' : 'text-gray-300'}`}
              >
                English (EN)
              </button>
              <button
                onClick={() => changeLang('ru')}
                className={`w-full text-left px-4 py-2 text-sm hover:bg-white/5 transition-colors ${lang === 'ru' ? 'text-blue-400 font-medium' : 'text-gray-300'}`}
              >
                Русский (RU)
              </button>
            </div>
          )}
        </div>
        {/* Background Gradients */}
        <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-blue-600/20 blur-[120px] rounded-full pointer-events-none" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-purple-600/20 blur-[120px] rounded-full pointer-events-none" />

        <div className="relative z-10 w-full max-w-md p-8 backdrop-blur-xl bg-white/5 border border-white/10 shadow-2xl rounded-3xl">
          {/* Logo */}
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/30">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60">
              Antigravity
            </h1>
            <p className="text-sm text-gray-400 mt-2 text-center">
              {t.secureClient}
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            {/* Server Status Display */}
            <div>
              <div className="flex items-center justify-between bg-black/40 border border-white/10 rounded-xl p-3 px-4">
                <div className="flex items-center space-x-3">
                  <Globe className="h-5 w-5 text-purple-400" />
                  <span className="text-sm font-medium text-gray-300">{t.serverStatus}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`text-sm font-bold ${
                    ping === null ? 'text-red-400' :
                    ping < 50 ? 'text-emerald-400' :
                    ping < 150 ? 'text-amber-400' : 'text-rose-400'
                  }`}>
                    {ping !== null ? `${ping} ms` : 'Offline'}
                  </span>
                  {serverOnline === true && <Wifi className="h-4 w-4 text-emerald-400" />}
                  {serverOnline === false && <WifiOff className="h-4 w-4 text-red-400" />}
                  {serverOnline === null && <div className="h-4 w-4 rounded-full bg-gray-600" />}
                </div>
              </div>
            </div>

            {/* Token Input */}
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                {t.accessToken}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Key className="h-5 w-5 text-gray-500" />
                </div>
                <input
                  type="password"
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  className="block w-full pl-11 pr-4 py-3 bg-black/40 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all outline-none"
                  placeholder="IMPULS-..."
                  required
                />
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="text-red-400 text-sm bg-red-400/10 p-3 rounded-lg border border-red-400/20">
                {error}
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading || !token}
              className="w-full py-3 px-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white rounded-xl font-medium shadow-lg shadow-purple-500/25 transition-all flex items-center justify-center group disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <RefreshCw className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <LogIn className="w-5 h-5 mr-2 group-hover:translate-x-1 transition-transform" />
                  {t.connect}
                </>
              )}
            </button>
          </form>
          
          <div className="mt-6 flex items-center justify-center space-x-8">
            <a 
              href="https://t.me/Ultimateadvansed" 
              target="_blank" 
              rel="noreferrer" 
              className="inline-flex items-center space-x-2 text-gray-500 hover:text-[#2AABEE] text-xs transition-colors"
            >
              <Key className="w-4 h-4" />
              <span>{t.getToken}</span>
            </a>

            <a 
              href="https://t.me/Ultimateadvansed" 
              target="_blank" 
              rel="noreferrer" 
              className="inline-flex items-center space-x-2 text-gray-500 hover:text-[#2AABEE] text-xs transition-colors"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.223-.548.223l.188-2.85 5.18-4.68c.223-.198-.05-.31-.346-.11l-6.4 4.03-2.76-.864c-.6-.188-.61-.6.125-.89l10.8-4.16c.5-.188.94.108.79.89z"/>
              </svg>
              <span>{t.support}</span>
            </a>
          </div>
        </div>
      </div>
    );
  }

  // ─── Render: Dashboard ──────────────────────────────────────────

  // Group models by category
  const groupedModels: Record<string, ModelInfo[]> = {};
  models.forEach(m => {
    const cat = getModelCategory(m.id);
    if (!groupedModels[cat.label]) groupedModels[cat.label] = [];
    groupedModels[cat.label].push(m);
  });

  
  const getRemainingDays = (timestamp: number) => {
    const diff = timestamp * 1000 - Date.now();
    if (diff <= 0) return 0;
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] p-6 relative overflow-hidden text-white font-sans flex flex-col items-center">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[80%] h-[500px] bg-blue-600/10 blur-[150px] pointer-events-none" />

      <div className="w-full max-w-4xl relative z-10">
        {/* ─── Header ──────────────────────────────────────────── */}
        <div className="flex justify-between items-center mb-6">
                    <div className="flex items-center space-x-3">
            {/* Language Dropdown */}
            <div className="relative lang-dropdown">
              <button
                onClick={() => setShowLangDropdown(!showLangDropdown)}
                className="flex items-center space-x-1 px-3 h-10 bg-white/5 hover:bg-white/10 rounded-lg transition-colors border border-white/5 text-sm font-medium text-gray-300"
                title="Change Language"
              >
                <Globe className="w-4 h-4" />
                <span>{lang.toUpperCase()}</span>
                <ChevronDown className={`w-4 h-4 transition-transform ${showLangDropdown ? 'rotate-180' : ''}`} />
              </button>
              
              {showLangDropdown && (
                <div className="absolute right-0 mt-2 w-32 bg-[#1a1c23] border border-white/10 rounded-xl shadow-2xl py-1 z-50 overflow-hidden">
                  <button
                    onClick={() => changeLang('en')}
                    className={`w-full text-left px-4 py-2 text-sm hover:bg-white/5 transition-colors ${lang === 'en' ? 'text-blue-400 font-medium' : 'text-gray-300'}`}
                  >
                    English (EN)
                  </button>
                  <button
                    onClick={() => changeLang('ru')}
                    className={`w-full text-left px-4 py-2 text-sm hover:bg-white/5 transition-colors ${lang === 'ru' ? 'text-blue-400 font-medium' : 'text-gray-300'}`}
                  >
                    Русский (RU)
                  </button>
                </div>
              )}
            </div>
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-xl font-bold text-white">Antigravity Client</h2>
                <span className="text-[10px] font-mono bg-white/10 text-gray-300 px-1.5 py-0.5 rounded-md border border-white/5">v{CURRENT_VERSION}</span>
              </div>
              <div className="flex items-center space-x-2 text-xs text-gray-400 mt-0.5">
                <CheckCircle className="w-3 h-3 text-emerald-400" />
                <span>{t.connected}. {t.ping}: {ping !== null ? `${ping} ms` : '...'}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={handleRefresh}
              className="p-2 bg-white/5 hover:bg-white/10 rounded-lg transition-colors border border-white/5"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 text-gray-300 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="p-2 bg-white/5 hover:bg-white/10 rounded-lg transition-colors border border-white/5"
              title="Settings"
            >
              <Settings className="w-4 h-4 text-gray-300" />
            </button>
            <button
              onClick={handleLogout}
              className="text-sm px-3 py-2 bg-white/5 hover:bg-red-500/20 hover:text-red-400 rounded-lg transition-colors border border-white/5 flex items-center space-x-1"
            >
              <LogOut className="w-4 h-4" />
              <span>{t.logout}</span>
            </button>
          </div>
        </div>

        {/* ─── Settings Panel ──────────────────────────────────── */}
        {showSettings && (
          <div className="mb-6 backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl p-5 animate-in fade-in slide-in-from-top-2">
            <h3 className="text-sm font-semibold text-gray-300 mb-3 flex items-center space-x-2">
              <Server className="w-4 h-4" />
              <span>{t.serverConfig}</span>
            </h3>
            <div className="flex space-x-3">
              <input
                type="text"
                value={serverUrl}
                onChange={(e) => setServerUrl(e.target.value.replace(/\/+$/, ''))}
                className="flex-1 px-4 py-2.5 bg-black/40 border border-white/10 rounded-xl text-white text-sm focus:ring-2 focus:ring-blue-500/50 outline-none"
                placeholder={lang === "ru" ? "http://сервер:8045" : "http://server:8045"}
              />
              <button
                onClick={handleSaveServerUrl}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-medium transition-colors"
              >
                {t.saveReconnect}
              </button>
            </div>
            <div className="mt-3 flex items-center space-x-4 text-xs text-gray-500">
              <span>{t.proxyUrlForIde} <code className="text-gray-400">{serverUrl}/v1</code></span>
            </div>
          </div>
        )}

        {/* ─── Error Banner ────────────────────────────────────── */}
        {error && (
          <div className="mb-6 text-red-400 text-sm bg-red-400/10 p-4 rounded-xl border border-red-400/20 flex items-start space-x-3">
            <XCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-medium">{t.error}</p>
              <p className="text-red-300/80 mt-1">{error}</p>
            </div>
          </div>
        )}

        {/* ─── Client Update Banner ────────────────────────────── */}
        {updateStatus === 'available' && updateInfo && (
          <div className="mb-6 backdrop-blur-xl bg-blue-500/10 border border-blue-500/30 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0 sm:space-x-4 animate-in fade-in slide-in-from-top-2">
            <div className="flex items-center space-x-3 text-left">
              <div className="p-3 bg-blue-500/20 rounded-xl border border-blue-500/30 flex-shrink-0">
                <Cpu className="w-6 h-6 text-blue-400 animate-pulse" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">
                  {t.updateAvailable}: {updateInfo.name}
                </h4>
                <p className="text-xs text-gray-400 mt-1 max-w-xl truncate">
                  {updateInfo.body || 'No release description provided.'}
                </p>
              </div>
            </div>
            <button
              onClick={handleInstallUpdate}
              disabled={updating}
              className="flex-shrink-0 whitespace-nowrap flex items-center space-x-2 px-5 py-3 bg-blue-500 hover:bg-blue-600 disabled:bg-blue-800 text-white rounded-xl text-sm font-medium transition-all shadow-[0_0_20px_rgba(59,130,246,0.3)] disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {updating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{t.updating}</span>
                </>
              ) : (
                <>
                  <span>{t.updateBtn}</span>
                </>
              )}
            </button>
          </div>
        )}

        {updateError && (
          <div className="mb-6 bg-red-500/10 border border-red-500/30 rounded-2xl p-4 flex items-center justify-between text-red-400 text-sm animate-in fade-in slide-in-from-top-2">
            <span>{t.updateError}: {updateError}</span>
            <button onClick={() => setUpdateError('')} className="text-xs font-semibold hover:underline">Dismiss</button>
          </div>
        )}

        {/* ─── Main Grid ───────────────────────────────────────── */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-5 mb-6">

          {/* Connection Status Card */}
          <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl p-6 relative overflow-hidden group">
            <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-emerald-500/10 blur-[50px] group-hover:bg-emerald-500/20 transition-all" />
            <div className="flex items-center space-x-3 mb-3">
              <div className="p-2 bg-emerald-500/20 rounded-lg border border-emerald-500/30">
                <Wifi className="w-4 h-4 text-emerald-400" />
              </div>
              <h3 className="text-sm font-medium text-gray-300">{t.status}</h3>
            </div>
            <div className="text-2xl font-bold text-emerald-400 mb-1">{t.active}</div>
            <div className="flex flex-col text-xs text-gray-500 space-y-0.5">
              {tier !== null && tier > 0 && (
                <span className="font-semibold text-gray-300">
                  {t.plan} X{tier}
                </span>
              )}
              <span>
                {expiresAt ? `${getRemainingDays(expiresAt)} ${t.daysLeft}` : t.tokenAuth}
              </span>
            </div>
          </div>

          {/* Models Count Card */}
          <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl p-6 relative overflow-hidden group">
            <div className="absolute -top-10 -left-10 w-32 h-32 bg-blue-500/10 blur-[50px] group-hover:bg-blue-500/20 transition-all" />
            <div className="flex items-center space-x-3 mb-3">
              <div className="p-2 bg-blue-500/20 rounded-lg border border-blue-500/30">
                <Cpu className="w-4 h-4 text-blue-400" />
              </div>
              <h3 className="text-sm font-medium text-gray-300">{t.models}</h3>
            </div>
            <div className="text-2xl font-bold text-white mb-1">{models.length}</div>
            <div className="text-xs text-gray-500">{t.availModels}</div>
          </div>

          {/* Credits Card */}
          <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl p-6 relative overflow-hidden group flex flex-col justify-between">
            <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-amber-500/10 blur-[50px] group-hover:bg-amber-500/20 transition-all" />
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-amber-500/20 rounded-lg border border-amber-500/30">
                    <Zap className="w-4 h-4 text-amber-400" />
                  </div>
                  <h3 className="text-sm font-medium text-gray-300">{t.credits}</h3>
                </div>
                <div className="flex items-center">
                  <label className="relative inline-flex items-center cursor-pointer" title="Enable Credit Overages">
                    <input type="checkbox" className="sr-only peer" checked={creditOverages} onChange={toggleCreditOverages} />
                    <div className="w-9 h-5 bg-gray-600 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                  </label>
                </div>
              </div>
              <div className="text-2xl font-bold text-amber-400 mb-1">{totalCredits !== null ? totalCredits : '-'}</div>
              <div className="text-xs text-gray-500">{t.totalCredits}</div>
            </div>
          </div>

          {/* Server Card */}
          <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl p-6 relative overflow-hidden group">
            <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-purple-500/10 blur-[50px] group-hover:bg-purple-500/20 transition-all" />
            <div className="flex items-center space-x-3 mb-3">
              <div className="p-2 bg-purple-500/20 rounded-lg border border-purple-500/30">
                <Server className="w-4 h-4 text-purple-400" />
              </div>
              <h3 className="text-sm font-medium text-gray-300">{t.server}</h3>
            </div>
            <div className={`text-2xl font-bold mb-1 ${
              ping === null ? 'text-red-400' :
              ping < 50 ? 'text-emerald-400' :
              ping < 150 ? 'text-amber-400' : 'text-rose-400'
            }`}>
              {ping !== null ? `${ping} ms` : 'Offline'}
            </div>
            <div className="text-xs text-gray-500">{t.proxyPing}</div>
          </div>
        </div>

        {/* ─── Models List ─────────────────────────────────────── */}
        {models.length > 0 && (
          <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-500/20 rounded-lg border border-blue-500/30">
                  <Zap className="w-4 h-4 text-blue-400" />
                </div>
                <h3 className="text-base font-semibold text-gray-200">{t.availableModelsTitle}</h3>
              </div>
              <div className="flex items-center space-x-3">
                <span className="text-xs text-gray-500">{models.length} {t.modelsCount}</span>
                <button
                  onClick={handleRefresh}
                  className="p-1.5 bg-white/5 hover:bg-white/10 rounded-lg transition-colors border border-white/5 flex items-center space-x-1"
                  title="Update Limits"
                >
                  <RefreshCw className={`w-3.5 h-3.5 text-gray-400 ${loading ? 'animate-spin' : ''}`} />
                </button>
              </div>
            </div>

            <div className="space-y-3">
              {Object.entries(groupedModels).map(([category, categoryModels]) => {
                const catInfo = Object.values(MODEL_CATEGORIES).find(c => c.label === category)
                  || { label: category, color: 'from-purple-500 to-pink-400', icon: '◇' };
                
                return (
                  <div key={category}>
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="text-sm">{catInfo.icon}</span>
                      <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">{category}</span>
                      <span className="text-xs text-gray-600">({categoryModels.length})</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {categoryModels.map(model => {
                        const pct = modelPercentages[model.id] 
                          ?? modelPercentages[model.id.replace('-thinking', '')]
                          ?? modelPercentages[model.id.replace(/-high|-medium|-low/g, '')]
                          ?? modelPercentages[model.id.replace(/-high|-medium/g, '-low')];
                        const resetTime = modelResets[model.id]
                          ?? modelResets[model.id.replace('-thinking', '')]
                          ?? modelResets[model.id.replace(/-high|-medium|-low/g, '')]
                          ?? modelResets[model.id.replace(/-high|-medium/g, '-low')];
                        return (
                          <div
                            key={model.id}
                            className="flex flex-col space-y-1.5 px-3 py-2.5 bg-white/[0.03] hover:bg-white/[0.06] border border-white/5 rounded-xl transition-colors group/model"
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${catInfo.color} flex-shrink-0`} />
                                <span className="text-sm text-gray-300 truncate group-hover/model:text-white transition-colors" title={model.id}>
                                  {formatModelName(model.id)}
                                </span>
                              </div>
                              <div className="flex items-center space-x-1.5">
                                {pct !== undefined && pct < 100 && resetTime && (
                                  <CountdownTimer resetTime={resetTime} />
                                )}
                                {pct !== undefined && (
                                  <span className="text-[10px] text-gray-500 font-mono">{pct}%</span>
                                )}
                              </div>
                            </div>
                            {pct !== undefined && (
                              <div className="w-full bg-white/10 rounded-full h-1 mt-1 overflow-hidden">
                                <div className={`h-1 rounded-full bg-gradient-to-r ${catInfo.color}`} style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}></div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ─── Connect to IDE ──────────────────────────────────── */}
        <div className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl p-8 flex flex-col items-center justify-center text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500/20 to-purple-600/20 rounded-full flex items-center justify-center mb-6 border border-white/10">
            <Shield className="w-8 h-8 text-blue-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">{t.ready}</h2>
          <p className="text-gray-400 max-w-lg mb-8">
            Connect to Antigravity IDE with your secure proxy token. A local proxy on port 8047 will route all IDE requests through the Manager.
          </p>

          {/* Proxy Status Badge */}
          {proxyRunning && (
            <div className="mb-6 flex items-center space-x-3">
              <div className="flex items-center space-x-2 text-emerald-400 bg-emerald-400/10 px-4 py-3 rounded-xl border border-emerald-400/20">
                <Activity className="w-4 h-4 animate-pulse" />
                <span className="text-sm font-medium">{t.localProxy} :8047</span>
              </div>
              <button
                onClick={handleStopProxy}
                className="flex items-center space-x-1 px-3 py-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl border border-red-400/20 transition-colors text-sm"
              >
                <Square className="w-3 h-3" />
                <span>{t.stop}</span>
              </button>
            </div>
          )}

          {ideSuccess && (
            <div className="mb-6 flex items-center space-x-2 text-emerald-400 bg-emerald-400/10 px-4 py-3 rounded-xl border border-emerald-400/20">
              <CheckCircle className="w-5 h-5" />
              <span className="text-sm font-medium">{t.ideLaunched}</span>
            </div>
          )}

          {/* IDE Selection */}
          <div className="flex space-x-2 bg-black/40 p-1.5 rounded-xl border border-white/10 mb-6">
            <button
              onClick={() => {
                setIdeType('Antigravity IDE');
                localStorage.setItem(LS_IDE_TYPE_KEY, 'Antigravity IDE');
              }}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                ideType === 'Antigravity IDE' 
                  ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' 
                  : 'text-gray-400 hover:text-gray-200 border border-transparent'
              }`}
            >
              Antigravity IDE
            </button>
            <button
              onClick={() => {
                setIdeType('Antigravity 2.0');
                localStorage.setItem(LS_IDE_TYPE_KEY, 'Antigravity 2.0');
              }}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                ideType === 'Antigravity 2.0' 
                  ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30' 
                  : 'text-gray-400 hover:text-gray-200 border border-transparent'
              }`}
            >
              Antigravity 2.0
            </button>
          </div>

          <button
            onClick={handleConnect}
            disabled={ideConnecting}
            className="group relative px-8 py-4 bg-white text-black font-semibold rounded-2xl text-lg hover:scale-105 transition-all duration-300 shadow-[0_0_40px_rgba(255,255,255,0.3)] hover:shadow-[0_0_60px_rgba(255,255,255,0.5)] flex items-center space-x-3 overflow-hidden disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-black/5 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]" />
            {ideConnecting ? (
              <RefreshCw className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <span>{proxyRunning ? t.reconnect : `${t.connectTo} ${ideType}`}</span>
                <ExternalLink className="w-5 h-5" />
              </>
            )}
          </button>
        </div>
      </div>

      {/* ─── Settings Modal ──────────────────────────────────── */}
      {showSettings && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-[#1a1c23] border border-white/10 rounded-2xl w-full max-w-lg shadow-2xl flex flex-col">
            <div className="flex items-center justify-between p-6 border-b border-white/10">
              <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                <Settings className="w-5 h-5 text-gray-400" />
                <span>{t.ideSettings}</span>
              </h2>
              <button 
                onClick={() => setShowSettings(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>
            
            <div className="p-6 space-y-6 overflow-y-auto">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300 block">
                  Custom Executable Path (Optional)
                </label>
                <input
                  type="text"
                  placeholder={`e.g. C:\\Apps\\${ideType}\\Antigravity.exe`}
                  value={customExePath}
                  onChange={(e) => {
                    setCustomExePath(e.target.value);
                    localStorage.setItem(LS_CUSTOM_EXE_KEY, e.target.value);
                  }}
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-mono text-sm"
                />
                <p className="text-xs text-gray-500">{t.leaveBlank}</p>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300 block">
                  Custom DB / AppData Path (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. C:\\Data\\User\\globalStorage\\state.vscdb"
                  value={customDbPath}
                  onChange={(e) => {
                    setCustomDbPath(e.target.value);
                    localStorage.setItem(LS_CUSTOM_DB_KEY, e.target.value);
                  }}
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 font-mono text-sm"
                />
                <p className="text-xs text-gray-500">{t.pathToVscdb}</p>
              </div>

              <div className="border-t border-white/5 pt-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-semibold text-white">{t.checkForUpdates}</h3>
                    <p className="text-xs text-gray-500 mt-0.5">Current Version: {CURRENT_VERSION}</p>
                  </div>
                  <button
                    onClick={() => checkUpdates(false)}
                    disabled={checkingUpdates || updating}
                    className="px-4 py-2 bg-white/5 hover:bg-white/10 text-gray-300 rounded-xl text-sm font-semibold border border-white/5 transition-colors flex items-center space-x-1.5 disabled:opacity-50"
                  >
                    {checkingUpdates && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                    <span>{t.checkForUpdates}</span>
                  </button>
                </div>

                {updateStatus === 'up-to-date' && (
                  <p className="text-xs text-emerald-400">{t.upToDate}</p>
                )}

                {updateStatus === 'available' && updateInfo && (
                  <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-xl space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-blue-400">{t.updateAvailable}: {updateInfo.name}</span>
                      <button
                        onClick={handleInstallUpdate}
                        disabled={updating}
                        className="flex-shrink-0 whitespace-nowrap px-3 py-1.5 bg-blue-500 hover:bg-blue-600 text-white rounded-lg text-xs font-semibold transition-colors flex items-center space-x-1"
                      >
                        {updating ? (
                          <>
                            <RefreshCw className="w-3 animate-spin" />
                            <span>{t.updating}</span>
                          </>
                        ) : (
                          <span>{t.updateBtn}</span>
                        )}
                      </button>
                    </div>
                  </div>
                )}

                {updateStatus === 'error' && updateError && (
                  <p className="text-xs text-red-400">{t.updateError}: {updateError}</p>
                )}
              </div>
            </div>
            
            <div className="p-6 border-t border-white/10 flex justify-end">
              <button
                onClick={() => setShowSettings(false)}
                className="px-6 py-2.5 bg-white text-black font-semibold rounded-xl hover:bg-gray-200 transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
